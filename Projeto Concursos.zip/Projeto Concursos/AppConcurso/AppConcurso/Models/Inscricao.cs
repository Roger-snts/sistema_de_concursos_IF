﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AppConcurso.Models
{
    [Table("inscricao")]
    public class Inscricao
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("numero_insc")]
        public int? NumeroInscricao { get; set; }
        [Column("data_inscricao")]
        public DateTime DataInscricao { get; set; }
        [Column("nota_conh_gerais")]
        public decimal? NotaConhecimentosGerais { get; set; }
        [Column("nota_conh_especificos")]
        public decimal? NotaConhecimentosEspecificos { get; set; }
        [Column("candidato_id")]
        public int CandidatoID { get; set; }
        [Column("cargo_id")]
        public int CargoID { get; set; }

        [ForeignKey("CandidatoID")]
        public Candidato? Candidato { get; set; }
        [ForeignKey("CargoID")]
        public Cargo? Cargo{ get; set; }
    }
}
