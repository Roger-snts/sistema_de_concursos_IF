﻿using AppConcurso.Contexto;
using AppConcurso.Models;
using Microsoft.EntityFrameworkCore;

namespace AppConcurso.Controllers
{
    public class InscricaoController
    {
        private readonly ContextoBD _context;

        public InscricaoController(ContextoBD context)
        {
            _context = context;
        }

        public async Task<List<Inscricao>?> ListarInscricoes()
        {
            var inscricoes = await _context.Inscricoes.Include(x => x.Cargo).Include(p => p.Candidato).ToListAsync();
            return inscricoes;
        }

        public async Task CadastrarInscricao(Inscricao inscricao)
        {
            await _context.AddAsync(inscricao);
        }

        public async Task<Inscricao?> BuscarInscricao(int numero)
        {
            var inscricao = await _context.Inscricoes.Where(t => t.NumeroInscricao == numero).Include(x => x.Candidato).Include(p => p.Cargo).FirstOrDefaultAsync();
            return inscricao;
        }

        public async Task SalvarAlteracoes()
        {
            await _context.SaveChangesAsync();
        }
    }
}
