﻿using AppConcurso.Contexto;
using AppConcurso.Models;
using Microsoft.EntityFrameworkCore;

namespace AppConcurso.Controllers
{
    public class CargoController
    {
        private readonly ContextoBD _context;

        public CargoController(ContextoBD context)
        {
            _context = context;
        }

        public async Task<List<Cargo>?> ListarCargos()
        {
            var candidatos = await _context.Cargos.Include(x => x.Inscricoes).ToListAsync();
            return candidatos;
        }

        public async Task CadastrarCargo(Cargo cargo)
        {
            await _context.AddAsync(cargo);
        }

        public async Task<Cargo?> BuscarCargo(string nome)
        {
            var cargo = await _context.Cargos.Where(p => p.NomeCargo == nome).Include(x => x.Inscricoes).FirstOrDefaultAsync();
            return cargo;
        }

        public async Task SalvarAlteracoes()
        {
            await _context.SaveChangesAsync();
        }
    }
}
