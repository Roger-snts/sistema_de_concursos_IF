﻿using AppConcurso.Contexto;
using AppConcurso.Models;
using Microsoft.EntityFrameworkCore;

namespace AppConcurso.Controllers
{
    public class CandidatoController
    {
        private readonly ContextoBD _context;

        public CandidatoController(ContextoBD context)
        {
            _context = context;
        }

        public async Task<List<Candidato>?> ListarCandidatos()
        {
            var candidatos = await _context.Candidatos.Include(x => x.Inscricoes).ToListAsync();
            return candidatos;
        }

        public async Task CadastrarCandidato(Candidato candidato)
        {
            await _context.AddAsync(candidato);
        }

        public async Task<Candidato?> BuscarCandidato(string nome)
        {
            var candidato = await _context.Candidatos.Where(p => p.Nome == nome).Include(x => x.Inscricoes).FirstOrDefaultAsync();
            return candidato;
        }

        public async Task SalvarAlteracoes()
        {
            await _context.SaveChangesAsync();
        }
    }
}
