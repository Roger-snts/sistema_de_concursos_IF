-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema bd_concursos
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bd_concursos
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bd_concursos` DEFAULT CHARACTER SET utf8 ;
USE `bd_concursos` ;

-- -----------------------------------------------------
-- Table `bd_concursos`.`candidato`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_concursos`.`candidato` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  `cpf` VARCHAR(45) NULL,
  `data_nascimento` DATE NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bd_concursos`.`cargo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_concursos`.`cargo` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome_cargo` VARCHAR(45) NULL,
  `edital` VARCHAR(60) NULL,
  `salario_base` DECIMAL NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bd_concursos`.`inscricao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_concursos`.`inscricao` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `numero_insc` VARCHAR(45) NULL,
  `data_inscricao` DATE NULL,
  `nota_conh_gerais` DECIMAL NULL,
  `nota_conh_especificos` DECIMAL NULL,
  `candidato_id` INT NOT NULL,
  `cargo_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_inscricao_candidato_idx` (`candidato_id` ASC) VISIBLE,
  INDEX `fk_inscricao_cargo1_idx` (`cargo_id` ASC) VISIBLE,
  CONSTRAINT `fk_inscricao_candidato`
    FOREIGN KEY (`candidato_id`)
    REFERENCES `bd_concursos`.`candidato` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_inscricao_cargo1`
    FOREIGN KEY (`cargo_id`)
    REFERENCES `bd_concursos`.`cargo` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;



INSERT INTO candidato ( nome, cpf, data_nascimento) values ('Ana Maria Souza','12345678998','1985-12-01');
INSERT INTO candidato ( nome, cpf, data_nascimento) values ('Bruno Souza','98765432132','1990-10-30');
INSERT INTO candidato ( nome, cpf, data_nascimento) values ('Carina Silva','15975345698','1995-09-05');
INSERT INTO candidato ( nome, cpf, data_nascimento) values ('Daniel Carvalho','98732165485','1984-08-07');



INSERT INTO cargo ( nome_cargo, edital, salario_base) values ('agente administrativo','Edital 15  de 22 de março de 2024','2500');
INSERT INTO cargo ( nome_cargo, edital, salario_base) values ('auxiliar de limpeza','Edital 15  de 22 de março de 2024','1800');
INSERT INTO cargo ( nome_cargo, edital, salario_base) values ('vigilante','Edital 16  de 22 de março de 2024','2000');
INSERT INTO cargo ( nome_cargo, edital, salario_base) values ('auxiliar de serviiços gerais','Edital 16  de 22 de março de 2024','1600');
INSERT INTO cargo ( nome_cargo, edital, salario_base) values ('Engenheiro ','Edital 17  de 22 de março de 2024','8000');
INSERT INTO cargo ( nome_cargo, edital, salario_base) values ('Analista de Sistemas','Edital 17  de 22 de março de 2024','8500');
